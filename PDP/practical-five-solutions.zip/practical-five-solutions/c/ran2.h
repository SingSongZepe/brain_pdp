#ifndef _RAN2_H
#define _RAN2_H

float ran2(long *);

#endif
