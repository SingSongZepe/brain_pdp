#include <sys/time.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <time.h>
#include "pool.h"
#include "mpi.h"

#define BUFFER_SIZE 1024*1024*10
#define MAX_NUMBER_CONCURRENT_AIRCRAFT 8
#define INITIAL_AIRCRAFT 2
#define DAY_LENGTH 10
#define MAX_DAYS 10

#define AIRSPACE_ACTOR_RANK 1
#define CTRL_TOWER_ACTOR_RANK 2
#define RUNWAY_ACTOR_RANK 3

#define LAND_REQUEST 0
#define LANDING 1
#define LANDED 2
#define PASS_AIRCRAFT_OVER 3
#define RETRIEVE_STATISTICS 4
#define FINISH 5

#define PERMISSION_GRANTED 0
#define PERMISSION_REFUSED 1

#define LANDED_SUCCESS 0

static void createInitialActor(int);
static void workerCode();
static void airspace();
static void control_tower(int);
static void runway();
static void aircraft();

int main(int argc, char * argv[]) {
	int rank, size, i, detachsize;
	MPI_Init(&argc, &argv);
	MPI_Comm_rank(MPI_COMM_WORLD, &rank);
	MPI_Comm_size(MPI_COMM_WORLD, &size);
	srand(time(NULL));

	char * buffer = (char*) malloc(BUFFER_SIZE);
	MPI_Buffer_attach(buffer, BUFFER_SIZE);

	int statusCode = processPoolInit();
	if (statusCode == 1) {		
		workerCode();
	} else if (statusCode == 2) {
		createInitialActor(0);
		createInitialActor(1);
		createInitialActor(2);
		for (i=0;i<INITIAL_AIRCRAFT;i++) {
			createInitialActor(3);
		}
		int masterStatus = masterPoll();
		while (masterStatus) {
			masterStatus=masterPoll();
		}
	}
	processPoolFinalise();
  MPI_Buffer_detach(buffer, &detachsize);
	MPI_Finalize();
	return 0;
}

static void createInitialActor(int type) {
	int data[1];
	int workerPid = startWorkerProcess();	
	data[0]=type;
	MPI_Bsend(data, 1, MPI_INT, workerPid, 0, MPI_COMM_WORLD);	
}

static void workerCode() {	
	int workerStatus = 1, data[1];
	while (workerStatus) {
		int parentId = getCommandData();
		MPI_Recv(data, 1, MPI_INT, parentId, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
		if (data[0] == 0) {
			airspace(INITIAL_AIRCRAFT);
		} else if (data[0] == 1) {
			control_tower(INITIAL_AIRCRAFT);
		} else if (data[0] == 2) {
			runway();
		} else if (data[0] == 3) {
			aircraft();
		}		
		workerStatus=workerSleep();
	}
}

static void airspace(int initialAircraft) {
	int failed_passes=0, stat_data[2];
	int new_ac_data[2], atcdata, outstanding_pass_over=0, elements, stat_day;
	int outstanding_retrieve_stats=0, finish_actor=0, outstanding,  total_aircraft=initialAircraft;
	MPI_Status status;
	struct timeval curr_time;
	gettimeofday(&curr_time, NULL);
	time_t seconds=0, start_seconds=0, pass_ac_ms=0, ms;
	start_seconds=curr_time.tv_sec;
	pass_ac_ms=curr_time.tv_sec*1000 + curr_time.tv_usec/1000;
	while (1==1) {
		gettimeofday(&curr_time, NULL);
		ms=curr_time.tv_sec*1000 + curr_time.tv_usec/1000;
		if (ms - pass_ac_ms > 250) {
      pass_ac_ms=ms;
      if (!outstanding_pass_over) {
          total_aircraft++;
          atcdata=PASS_AIRCRAFT_OVER;
          MPI_Bsend(&atcdata, 1, MPI_INT, CTRL_TOWER_ACTOR_RANK, 0, MPI_COMM_WORLD);
          outstanding_pass_over=1;
        }
      }
		if (curr_time.tv_sec != seconds) {
			seconds=curr_time.tv_sec;			
			if ((seconds - start_seconds) % DAY_LENGTH == 0) {
				stat_day=(seconds - start_seconds) / DAY_LENGTH;
				atcdata=RETRIEVE_STATISTICS;
				MPI_Bsend(&atcdata, 1, MPI_INT, CTRL_TOWER_ACTOR_RANK, 0, MPI_COMM_WORLD);
				outstanding_retrieve_stats=1;
			}
			if ((seconds- start_seconds) > (DAY_LENGTH*MAX_DAYS)) {
				atcdata=FINISH;
				MPI_Bsend(&atcdata, 1, MPI_INT, CTRL_TOWER_ACTOR_RANK, 0, MPI_COMM_WORLD);
				finish_actor=1;
			}
		}
		if (!outstanding_pass_over && !outstanding_retrieve_stats && finish_actor) {			
			break;
		}
		MPI_Iprobe(CTRL_TOWER_ACTOR_RANK, 0, MPI_COMM_WORLD, &outstanding, &status);
		if (outstanding) {
			MPI_Get_count(&status, MPI_INT, &elements);
			if (elements == 1) {
				outstanding_pass_over=0;
				MPI_Recv(&atcdata, 1, MPI_INT, status.MPI_SOURCE, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
				if (atcdata == PERMISSION_GRANTED) {					
					int workerPid = startWorkerProcess();	
					new_ac_data[0]=3;						
					MPI_Bsend(new_ac_data, 1, MPI_INT, workerPid, 0, MPI_COMM_WORLD);
				} else {
					failed_passes++;
				}
			} else if (elements == 2) {
				MPI_Recv(stat_data, 2, MPI_INT, status.MPI_SOURCE, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
				printf("Status at day %d\nTotal number of aircraft: %d, Number of successful landings: %d, Number aircraft refused %d, Number being handled by ATC: %d\n\n", stat_day, 
						total_aircraft, stat_data[0], failed_passes, stat_data[1]);
				outstanding_retrieve_stats=0;
			} else {
				printf("Airspace has got %d elements and is not sure how to handle this\n", elements);
			}
		}
	}
}

static void control_tower(int initialAircraft) {
	int data, permission_data, stat_data[2];
	int runway_busy=0, successful_landings=0, current_aircraft_number=initialAircraft, finish_actor=0;
	MPI_Status status;	
	while (1==1) {		
		MPI_Recv(&data, 1, MPI_INT, MPI_ANY_SOURCE, 0, MPI_COMM_WORLD, &status);
		if (data == LAND_REQUEST) {
			if (!runway_busy) {
				runway_busy=1;
				permission_data=PERMISSION_GRANTED;
			} else {
				permission_data=PERMISSION_REFUSED;
			}
			MPI_Bsend(&permission_data, 1, MPI_INT, status.MPI_SOURCE, 0, MPI_COMM_WORLD);
		} else if (data == LANDED) {
			runway_busy=0;
			successful_landings++;
			current_aircraft_number--;	
		} else if (data == PASS_AIRCRAFT_OVER) {
			if (current_aircraft_number < MAX_NUMBER_CONCURRENT_AIRCRAFT) {
				current_aircraft_number++;
				permission_data=PERMISSION_GRANTED;
			} else {
				permission_data=PERMISSION_REFUSED;
			}
			MPI_Bsend(&permission_data, 1, MPI_INT, status.MPI_SOURCE, 0, MPI_COMM_WORLD);
		} else if (data == RETRIEVE_STATISTICS) {
			stat_data[0]=successful_landings;
			stat_data[1]=current_aircraft_number;			
			MPI_Bsend(stat_data, 2, MPI_INT, status.MPI_SOURCE, 0, MPI_COMM_WORLD);
		} else if (data == FINISH) {
			finish_actor=1;
		}
		if (finish_actor && runway_busy==0 && current_aircraft_number==0) {
			 shutdownPool();
			break;
		}
	}
}

static void runway() {
	int data, ack=LANDED, outstanding;
	MPI_Status status;
	while (1==1) {
		MPI_Iprobe(MPI_ANY_SOURCE, 0, MPI_COMM_WORLD, &outstanding, &status);
		if (outstanding) {
			MPI_Recv(&data, 1, MPI_INT, status.MPI_SOURCE, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
			if (data == LANDING) {
				MPI_Bsend(&ack, 1, MPI_INT, status.MPI_SOURCE, 0, MPI_COMM_WORLD);
			}
		}
		if (shouldWorkerStop())  break;					
	}
}

static void aircraft() {
	int data=LAND_REQUEST, returnedAck;
	MPI_Send(&data, 1, MPI_INT, CTRL_TOWER_ACTOR_RANK, 0, MPI_COMM_WORLD);
	MPI_Recv(&returnedAck, 1, MPI_INT, CTRL_TOWER_ACTOR_RANK, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
	while (returnedAck == PERMISSION_REFUSED) {
		sleep(1);				
		MPI_Bsend(&data, 1, MPI_INT, CTRL_TOWER_ACTOR_RANK, 0, MPI_COMM_WORLD);
		MPI_Recv(&returnedAck, 1, MPI_INT, CTRL_TOWER_ACTOR_RANK, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
	}
	data=LANDING;
	MPI_Bsend(&data, 1, MPI_INT, RUNWAY_ACTOR_RANK, 0, MPI_COMM_WORLD);
	MPI_Recv(&returnedAck, 1, MPI_INT, RUNWAY_ACTOR_RANK, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);	
	data=LANDED;	
	MPI_Bsend(&data, 1, MPI_INT, CTRL_TOWER_ACTOR_RANK, 0, MPI_COMM_WORLD);
}
