// Pipeline where the calculation part is duplicated to improve load balance
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include "mpi.h"

// Threshold of polution that needs to be cleaned
#define THRESHOLD_VALUE 18.75
// The maximum number of iterations
#define MAX_ITERATIONS 100000
// How often to report the norm
#define REPORT_NORM_PERIOD 1000

void initialise(double*, double*, int, int, double, double);
void read_files(int, char**);
void write_data(int);
void data_analysis(int, int, int, int);
void perform_calculation(int, int, double, int, int, int);
void average_sample_values(int);

double active_time;

int main(int argc, char * argv[]) {
	MPI_Init(&argc, &argv);
	active_time=0.0;
	double start_time=MPI_Wtime();

	if (argc < 5) {
  		fprintf(stderr, "You must provide four command line arguments, the global size in X, the global size in Y, convergence accuracy and max number iterations\n");
    	return -1;
  	}
  	int nx=atoi(argv[1]);
  	int ny=atoi(argv[2]);
  	double convergence_accuracy=atof(argv[3]);
  	int max_its=atoi(argv[4]);

	int myrank, size;
	MPI_Comm_rank(MPI_COMM_WORLD, &myrank);
	MPI_Comm_size(MPI_COMM_WORLD, &size);
	if (myrank == 0) {
		read_files(argc, argv);
	} else if (myrank == 1) {
		average_sample_values(size);
	} else if (myrank >= 2 && myrank <=size-3) {
		perform_calculation(nx, ny, convergence_accuracy, max_its, myrank, size-2);
	} else if (myrank == size-2) {
		data_analysis(nx, ny, size-1, size);
	} else if (myrank == size-1) {
		write_data(size-2);
	}
	double summed_active_time, maximum_active_time;
	MPI_Reduce(&active_time, &summed_active_time, 1, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);
	MPI_Reduce(&active_time, &maximum_active_time, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);
	if (myrank == 0) printf("Average utilisation %f, maximum utilisation %f, LIF %f\n", summed_active_time/size, maximum_active_time, maximum_active_time / (summed_active_time/size));

	if (myrank == 0) printf("Overall runtime %f seconds\n", MPI_Wtime() - start_time);
	MPI_Finalize();
	return 0;
}

void read_files(int argc, char * argv[]) {
	FILE * fileHandle;
	char buffer[3000], *nextSep, *buffer_point;
	double extractedValues[60];
	int i, j,n;
	for (i=5;i<argc;i++) {
		double startTime=MPI_Wtime();
		fileHandle=fopen(argv[i], "r");
		if (fileHandle != NULL) {
			n=0;
			while (fgets(buffer, 3000, fileHandle) != NULL) {
				buffer_point=buffer;
				while (buffer_point != NULL) {
					nextSep=strchr(buffer_point, ',');
					if (nextSep != NULL) *nextSep='\0';
					extractedValues[n++]=atof(buffer_point);
					if (nextSep != NULL) {
						buffer_point=nextSep+1;
					} else {
						buffer_point=NULL;
					}
				}
			}
			fclose(fileHandle);
			active_time+=MPI_Wtime()-startTime;
			MPI_Send(extractedValues, 60, MPI_DOUBLE, 1, 0, MPI_COMM_WORLD);
		} else {
			printf("Warning: File %s does not exist\n", argv[i]);
		}
	}
	MPI_Send(NULL, 0, MPI_DOUBLE, 1, 0, MPI_COMM_WORLD);
}

void average_sample_values(int number_ranks) {
	double raw_sample_values[60], average_vals[2];
	MPI_Status message_status;
	int elements, i, next_rank=2;

	while (1==1) {
		MPI_Recv(raw_sample_values, 60, MPI_DOUBLE, 0, 0, MPI_COMM_WORLD, &message_status);
		double startTime=MPI_Wtime();
		MPI_Get_count(&message_status, MPI_INT, &elements);
		if (elements == 0) break;
		average_vals[0]=0.0;
		average_vals[1]=0.0;
		for (i=0;i<30;i++) {
			average_vals[0]+=raw_sample_values[i];
			average_vals[1]+=raw_sample_values[i+30];
		}
		average_vals[0]/=30;
		average_vals[1]/=30;
		active_time+=MPI_Wtime()-startTime;
		MPI_Send(average_vals, 2, MPI_DOUBLE, next_rank, 0, MPI_COMM_WORLD);
		next_rank++;
		if (next_rank > number_ranks-3) next_rank=2;
	}
	for (i=2;i<=number_ranks-3;i++) {
		MPI_Send(NULL, 0, MPI_INT, i, 0, MPI_COMM_WORLD);
	}
}

void write_data(int source) {
	int analysed_data[2];
	MPI_Status message_status;
	int elements, file_number=0;
	char file_name[30];
	FILE * file_handle;

	while (1==1) {
		MPI_Recv(analysed_data, 2, MPI_INT, source, 0, MPI_COMM_WORLD, &message_status);
		double startTime=MPI_Wtime();
		MPI_Get_count(&message_status, MPI_INT, &elements);
		if (elements == 0) break;
		sprintf(file_name, "results/results_%d", file_number);
		file_handle=fopen(file_name, "w");
		fprintf(file_handle, "Sample number %d\nPollution starts at grid point %d\nNumber of grid points over threshold that need cleaning %d\n", file_number, analysed_data[0],
				analysed_data[1]);
		fclose(file_handle);
		printf("Result file is: %s\n", file_name);
		file_number++;
		active_time+=MPI_Wtime()-startTime;
	}
}

void data_analysis(int nx, int ny, int target, int size) {
	int mem_size_x=nx+2;
  	int mem_size_y=ny+2;

	double * u_k = malloc(sizeof(double) * mem_size_x * mem_size_y);
	int i, j, analysed_data[2];
	short past_threshold=0;
	MPI_Status message_status;
	int elements, number_poisoned_pills=0;

	while (1==1) {
		MPI_Recv(u_k, mem_size_x * mem_size_y, MPI_DOUBLE, MPI_ANY_SOURCE, 0, MPI_COMM_WORLD, &message_status);
		double startTime=MPI_Wtime();
		MPI_Get_count(&message_status, MPI_DOUBLE, &elements);
		if (elements == 0) {
			number_poisoned_pills++;
			if (number_poisoned_pills == size-4) break;
			continue;
		}

		past_threshold=0;
		analysed_data[0]=analysed_data[1]=0;
		for (i=0;i<mem_size_x;i++) {
			for (j=0;j<mem_size_y;j++) {
				double value=u_k[j+(i*mem_size_y)];			
				if (value >= THRESHOLD_VALUE) {
					if (!past_threshold) {
						past_threshold=1;
						analysed_data[0]=j;
					}
					analysed_data[1]++;
				}
			}
		}
		active_time+=MPI_Wtime()-startTime;
		MPI_Send(analysed_data, 2, MPI_INT, target, 0, MPI_COMM_WORLD);
	}
	MPI_Send(NULL, 0, MPI_INT, target, 0, MPI_COMM_WORLD);
	free(u_k);
}

void perform_calculation(int nx, int ny, double convergence_accuracy, int max_its, int rank, int target) {
	int mem_size_x=nx+2;
  	int mem_size_y=ny+2;

  	double * u_k = malloc(sizeof(double) * mem_size_x * mem_size_y);
  	double * u_kp1 = malloc(sizeof(double) * mem_size_x * mem_size_y);
	double * temp, boundaryValues[2];
	MPI_Status message_status;
	int elements;

	while (1==1) {
		MPI_Recv(boundaryValues, 2, MPI_DOUBLE, 1, 0, MPI_COMM_WORLD, &message_status);
		double startTime=MPI_Wtime();
		MPI_Get_count(&message_status, MPI_DOUBLE, &elements);
		if (elements == 0) break;

		initialise(u_k, u_kp1, nx, ny, boundaryValues[0], boundaryValues[1]);

		double rnorm=0.0, bnorm=0.0, norm;

		int i, j, k;
		for (j=1;j<=nx;j++) {
    			for (i=1;i<=ny;i++) {
      				bnorm=bnorm+pow(u_k[i+(j*mem_size_y)]*4-u_k[(i-1)+(j*mem_size_y)]-
       	   				u_k[(i+1)+(j*mem_size_y)]-u_k[i+((j-1)*mem_size_y)]-u_k[i+((j+1)*mem_size_y)], 2);
    			}
  		}
		bnorm=sqrt(bnorm);

		for (k=0;k<MAX_ITERATIONS;k++) {
			rnorm=0.0;
    			// Calculates the current residual norm
    			for (j=1;j<=nx;j++) {
      				for (i=1;i<=ny;i++) {
        				rnorm=rnorm+pow(u_k[i+(j*mem_size_y)]*4-u_k[(i-1)+(j*mem_size_y)]-
          	  				u_k[(i+1)+(j*mem_size_y)]-u_k[i+((j-1)*mem_size_y)]-u_k[i+((j+1)*mem_size_y)], 2);
      				}
    			}
    			norm=sqrt(rnorm)/bnorm;
		
			if (norm < convergence_accuracy) break;
	    		if (max_its > 0 && k >= max_its) break;

			for (j=1;j<=nx;j++) {
      				for (i=1;i<=ny;i++) {
        				u_kp1[i+(j*mem_size_y)]=0.25 * (u_k[(i-1)+(j*mem_size_y)]+u_k[(i+1)+(j*mem_size_y)]+
          	  				u_k[i+((j-1)*mem_size_y)]+u_k[i+((j+1)*mem_size_y)]);
      				}
    			}

			temp=u_kp1; u_kp1=u_k; u_k=temp;
			rnorm=0.0;
		}
		active_time+=MPI_Wtime()-startTime;
		MPI_Send(u_k, mem_size_x*mem_size_y, MPI_DOUBLE, target, 0, MPI_COMM_WORLD);
	}
	MPI_Send(NULL, 0, MPI_DOUBLE, target, 0, MPI_COMM_WORLD);
	free(u_k);
	free(u_kp1);
}

/**
 * Initialises the arrays, such that u_k contains the boundary conditions at the start and end points and all other
 * points are zero. u_kp1 is set to equal u_k
 */
void initialise(double * u_k, double * u_kp1, int nx, int ny, double leftValue, double rightValue) {
	int i,j;
  	for (i=0;i<nx+1;i++) {
    		u_k[i*(ny+2)]=leftValue;
    		u_k[(ny+1)+(i*(ny+2))]=rightValue;
  	}
  	for (j=0;j<=nx+1;j++) {
    		for (i=1;i<=ny;i++) {
      			u_k[i+(j*(ny+2))]=0.0;
    		}
  	}
  	for (j=0;j<=nx+1;j++) {
    		for (i=0;i<=ny+1;i++) {
      			u_kp1[i+(j*(ny+2))]=u_k[i+(j*(ny+2))];
    		}
  	}
}

